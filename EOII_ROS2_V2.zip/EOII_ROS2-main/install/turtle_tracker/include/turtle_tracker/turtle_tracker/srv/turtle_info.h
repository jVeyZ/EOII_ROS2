// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtle_tracker:srv/TurtleInfo.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_TRACKER__SRV__TURTLE_INFO_H_
#define TURTLE_TRACKER__SRV__TURTLE_INFO_H_

#include "turtle_tracker/srv/detail/turtle_info__struct.h"
#include "turtle_tracker/srv/detail/turtle_info__functions.h"
#include "turtle_tracker/srv/detail/turtle_info__type_support.h"

#endif  // TURTLE_TRACKER__SRV__TURTLE_INFO_H_

// generated from rosidl_generator_c/resource/idl.h.em
// with input from turtle_tracker:action/TurtleInfoAction.idl
// generated code does not contain a copyright notice

#ifndef TURTLE_TRACKER__ACTION__TURTLE_INFO_ACTION_H_
#define TURTLE_TRACKER__ACTION__TURTLE_INFO_ACTION_H_

#include "turtle_tracker/action/detail/turtle_info_action__struct.h"
#include "turtle_tracker/action/detail/turtle_info_action__functions.h"
#include "turtle_tracker/action/detail/turtle_info_action__type_support.h"

#endif  // TURTLE_TRACKER__ACTION__TURTLE_INFO_ACTION_H_
